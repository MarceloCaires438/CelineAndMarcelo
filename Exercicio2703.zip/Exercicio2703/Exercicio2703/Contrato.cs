﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio2703
{
    public class Contrato : Documento, IImprimivel
    {
        public Contrato(string titulo) : base(titulo) { }
        public override void Processar()
        {
            Console.WriteLine("Processando Contrato. . . ");
        }
        public void imprimir ()
        {
            Console.WriteLine("O contrato está sendo imprimido");
        }
    }
}
