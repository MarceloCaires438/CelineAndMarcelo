﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio2703
{
    public interface IImprimivel
    {
        void imprimir();

    }
}
