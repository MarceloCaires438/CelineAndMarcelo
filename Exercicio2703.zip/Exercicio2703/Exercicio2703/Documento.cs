﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio2703
{
    public abstract class Documento
    {
        public string Titulo { get; set; }
        public Documento (string _Titulo)
        {
            Titulo = _Titulo;
        }
        public void exibirTitulo()
        {
            Console.WriteLine($"O Título do documento é {Titulo}");
        }
        public abstract void Processar();
    }
}
