﻿using Exercicio2703;

Relatorio relatorio1 = new Relatorio("Exemplo Relatório");
relatorio1.exibirTitulo();
relatorio1.Processar();
relatorio1.imprimir();


Contrato contrato1 = new Contrato("Admissional");
contrato1.exibirTitulo();
contrato1.Processar();
contrato1.imprimir();

