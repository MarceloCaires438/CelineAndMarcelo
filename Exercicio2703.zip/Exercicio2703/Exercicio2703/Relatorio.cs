﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio2703
{
    public class Relatorio : Documento, IImprimivel
    {
        public Relatorio(string titulo) : base(titulo) { }
        public override void Processar()
        {
            Console.WriteLine("Processando Relatório. . . ");
        }   
        

        public void imprimir ()
        {
            Console.WriteLine("O relatório está sendo imprimido");
        }
    }
}
